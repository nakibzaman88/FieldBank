﻿using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.Model
{
    internal abstract class Repository : IRepository 
    {
        protected SampleTransactionContext dbContext = new SampleTransactionContext();
        public abstract bool Add(Transaction model);
    }
}
