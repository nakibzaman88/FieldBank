﻿using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.Model
{
    internal class PaymentRepository : Repository
    {
        public  override bool Add(Transaction model)
        {   
            dbContext.Add(model);
            dbContext.SaveChanges();
            return true;
        }
    }
}
