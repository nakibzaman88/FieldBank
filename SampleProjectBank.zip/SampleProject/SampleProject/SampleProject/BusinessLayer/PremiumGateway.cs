﻿using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.BusinessLayer
{
    internal class PremiumGateway : Business, IPaymentGateway 
    {
        public bool ProcessPayment(Transaction paymentInfo)
        {
            bool status = false;
            // call validation function 3 times in case its failed
            int counter = 0;
            Validation validation = new Validation();
            while(counter <= 2)
            {
                status = validation.ValidateTransaction(paymentInfo);
                if (status)
                    break;
                else
                    counter++;
            }
            paymentInfo.Status = status == true ? "Completed" : "Failed";
            this.Add(paymentInfo);
            return status;
        }
    }
}
