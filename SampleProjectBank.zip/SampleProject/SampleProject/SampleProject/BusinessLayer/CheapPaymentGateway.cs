﻿using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.BusinessLayer
{
    internal class CheapPaymentGateway
        : Business, ICheapPaymentGateway
    {
        public bool ProcessPayment(Transaction paymentInfo)
        {
            if (paymentInfo != null && paymentInfo.Amount > 0)
            {
                Validation validation = new Validation();
                bool status = validation.ValidateTransaction(paymentInfo);
                paymentInfo.Status = status == true ? "Completed" : "Failed";
                this.Add(paymentInfo);
                return status;
            }
            else
                return false;
        }
    }
}
