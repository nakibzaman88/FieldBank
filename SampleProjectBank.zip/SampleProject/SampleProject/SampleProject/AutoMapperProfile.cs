﻿using AutoMapper;
using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<PaymentInfo, Transaction>();
        }
    }
}
