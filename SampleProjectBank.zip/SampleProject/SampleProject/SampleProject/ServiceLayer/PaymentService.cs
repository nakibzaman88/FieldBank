﻿using SampleProject.BusinessLayer;
using SampleProject.Model;
using SampleProject.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.ServiceLayer
{
    public class PaymentService : IPaymentService
    {
        public bool ProcessPayment(Transaction paymentInfo)
        {
            IPaymentGateway paymentGateway = BusinessFactory.Create(paymentInfo);
            if (paymentGateway != null)
                return paymentGateway.ProcessPayment(paymentInfo);
            else
                return false;
        }
    }
}
