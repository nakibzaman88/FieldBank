using Microsoft.VisualStudio.TestTools.UnitTesting;
using Xunit.Sdk;
using SampleProject.Model;
using System;
using SampleProject.ServiceLayer;

namespace UnitTest
{
    [TestClass]
    public class PaymentServiceTest
    {
        [TestMethod]
        public void ProcessPayment()
        {
            Transaction transaction = new Transaction()
            {
                CreditCardNumber = "1234567890123456",
                CardHolder = "Nakibuz Zaman",
                ExpirationDate = Convert.ToDateTime("2022-01-02"),
                Amount = 30,
                SecurityCode = "123"
            };

            IPaymentService _IPaymentService = new PaymentService();
            bool result = _IPaymentService.ProcessPayment(transaction);

            Assert.IsTrue(result);
        }
    }
}
